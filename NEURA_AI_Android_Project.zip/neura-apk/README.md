# NEURA AI Android wrapper

This project packages the supplied `index.html` as an Android WebView app. It is a starter/debug build, not a Play Store release.

## Build APK automatically (phone-friendly route)
1. Create/sign in to GitHub and create a **private** repository named `neura-ai-android`.
2. Upload the contents of this folder (not the outer ZIP) to the repository's `main` branch.
3. Open **Actions** → **Build NEURA AI APK** → **Run workflow** (or wait for the first push build).
4. When the workflow succeeds, open that run, scroll to **Artifacts**, and download `NEURA-AI-debug-APK`.
5. Extract the ZIP; it contains `app-debug.apk`. Transfer it to your Android phone and tap it to install. Android may ask permission to install from that source.

## Important notes
- This wraps the supplied HTML; it does not rewrite or fix the AI backend.
- The HTML currently points to a Cloudflare Worker. Its CORS configuration must permit the app origin `https://appassets.androidplatform.net`; otherwise API calls may fail inside the APK. The Worker source is needed to verify/fix this.
- The app requests microphone/camera permissions only if the web page asks for them. Grant only if you trust the feature.
- Do not commit API keys, passwords, or other secrets to GitHub. Keep the repository private while testing.
- This is a debug APK. A Play Store release needs a signed release build, privacy disclosures, testing, and policy review.
